package com.example.pokedex;

public class Constantes {
    public static final String TAG = "Pokedex";
    public static final String EXTRA_POKEMON_ID = "pokemon_id";
}
